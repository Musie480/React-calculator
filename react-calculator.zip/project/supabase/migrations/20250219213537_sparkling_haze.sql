/*
  # Initial Schema Setup for Student Registration System

  1. New Tables
    - profiles
      - id (uuid, primary key)
      - user_id (uuid, references auth.users)
      - full_name (text)
      - phone (text)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - courses
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - price (numeric)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - enrollments
      - id (uuid, primary key)
      - student_id (uuid, references profiles)
      - course_id (uuid, references courses)
      - status (text)
      - payment_status (text)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - payments
      - id (uuid, primary key)
      - enrollment_id (uuid, references enrollments)
      - amount (numeric)
      - status (text)
      - stripe_payment_id (text)
      - created_at (timestamp)
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE profiles (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users NOT NULL,
    full_name text,
    phone text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(user_id)
);

-- Create courses table
CREATE TABLE courses (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title text NOT NULL,
    description text,
    price numeric NOT NULL DEFAULT 0,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Create enrollments table
CREATE TABLE enrollments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id uuid REFERENCES profiles NOT NULL,
    course_id uuid REFERENCES courses NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    payment_status text NOT NULL DEFAULT 'pending',
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(student_id, course_id)
);

-- Create payments table
CREATE TABLE payments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    enrollment_id uuid REFERENCES enrollments NOT NULL,
    amount numeric NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    stripe_payment_id text,
    created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own profile"
    ON profiles FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
    ON profiles FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile"
    ON profiles FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

-- Courses are viewable by all authenticated users
CREATE POLICY "Courses are viewable by all authenticated users"
    ON courses FOR SELECT
    TO authenticated
    USING (true);

-- Enrollments policies
CREATE POLICY "Users can view their own enrollments"
    ON enrollments FOR SELECT
    TO authenticated
    USING (student_id IN (
        SELECT id FROM profiles WHERE user_id = auth.uid()
    ));

CREATE POLICY "Users can create their own enrollments"
    ON enrollments FOR INSERT
    TO authenticated
    WITH CHECK (student_id IN (
        SELECT id FROM profiles WHERE user_id = auth.uid()
    ));

-- Payments policies
CREATE POLICY "Users can view their own payments"
    ON payments FOR SELECT
    TO authenticated
    USING (enrollment_id IN (
        SELECT id FROM enrollments WHERE student_id IN (
            SELECT id FROM profiles WHERE user_id = auth.uid()
        )
    ));

CREATE POLICY "Users can create their own payments"
    ON payments FOR INSERT
    TO authenticated
    WITH CHECK (enrollment_id IN (
        SELECT id FROM enrollments WHERE student_id IN (
            SELECT id FROM profiles WHERE user_id = auth.uid()
        )
    ));

-- Insert some sample courses
INSERT INTO courses (title, description, price) VALUES
    ('Introduction to Computer Science', 'Learn the fundamentals of computer science and programming.', 299.99),
    ('Web Development Bootcamp', 'Comprehensive course on modern web development.', 499.99),
    ('Data Science Fundamentals', 'Introduction to data science and analytics.', 399.99),
    ('Digital Marketing Essentials', 'Learn the basics of digital marketing and social media.', 249.99);