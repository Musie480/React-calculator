import React from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { loadStripe } from '@stripe/stripe-js'
import { toast } from 'react-hot-toast'
import { CreditCard, AlertCircle } from 'lucide-react'

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)

type EnrollmentWithCourse = {
  id: string
  course: {
    title: string
    description: string
    price: number
  }
  payment_status: string
}

export default function Payment() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const enrollmentId = searchParams.get('enrollment')
  const [loading, setLoading] = React.useState(true)
  const [processing, setProcessing] = React.useState(false)
  const [enrollment, setEnrollment] = React.useState<EnrollmentWithCourse | null>(null)

  React.useEffect(() => {
    const fetchEnrollment = async () => {
      if (!enrollmentId) {
        navigate('/dashboard')
        return
      }

      try {
        const { data, error } = await supabase
          .from('enrollments')
          .select(`
            id,
            payment_status,
            course:courses (
              title,
              description,
              price
            )
          `)
          .eq('id', enrollmentId)
          .single()

        if (error) throw error
        setEnrollment(data)
      } catch (error) {
        console.error('Error fetching enrollment:', error)
        toast.error('Failed to load enrollment details')
        navigate('/dashboard')
      } finally {
        setLoading(false)
      }
    }

    fetchEnrollment()
  }, [enrollmentId, navigate])

  const handlePayment = async () => {
    if (!enrollment) return

    setProcessing(true)
    try {
      // In a real application, you would:
      // 1. Call your backend to create a Stripe payment intent
      // 2. Redirect to Stripe Checkout or show Stripe Elements
      // 3. Handle the payment confirmation
      
      // For demo purposes, we'll simulate a successful payment
      const { error } = await supabase
        .from('enrollments')
        .update({ payment_status: 'completed' })
        .eq('id', enrollment.id)

      if (error) throw error

      toast.success('Payment successful!')
      navigate('/dashboard')
    } catch (error) {
      console.error('Payment error:', error)
      toast.error('Payment failed')
    } finally {
      setProcessing(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  if (!enrollment) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="mx-auto h-12 w-12 text-red-500" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Enrollment not found</h3>
      </div>
    )
  }

  return (
    <div className="max-w-lg mx-auto">
      <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center justify-center mb-8">
          <CreditCard className="h-12 w-12 text-indigo-600" />
        </div>
        
        <h1 className="text-2xl font-bold text-center text-gray-900 mb-8">
          Complete Your Payment
        </h1>

        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h2 className="font-semibold text-gray-900">{enrollment.course.title}</h2>
            <p className="text-sm text-gray-600 mt-1">{enrollment.course.description}</p>
          </div>

          <div className="border-t border-b border-gray-200 py-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Course Price</span>
              <span className="text-lg font-semibold text-gray-900">
                ${enrollment.course.price.toFixed(2)}
              </span>
            </div>
          </div>

          <button
            onClick={handlePayment}
            disabled={processing || enrollment.payment_status === 'completed'}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {processing ? 'Processing...' : 'Pay Now'}
          </button>

          <p className="text-center text-sm text-gray-500">
            Secure payment powered by Stripe
          </p>
        </div>
      </div>
    </div>
  )
}