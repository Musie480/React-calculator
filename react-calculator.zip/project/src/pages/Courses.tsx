import React from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { toast } from 'react-hot-toast'
import { BookOpen, DollarSign } from 'lucide-react'

type Course = {
  id: string
  title: string
  description: string
  price: number
}

export default function Courses() {
  const navigate = useNavigate()
  const [courses, setCourses] = React.useState<Course[]>([])
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    const fetchCourses = async () => {
      try {
        const { data, error } = await supabase
          .from('courses')
          .select('*')
          .order('title')

        if (error) throw error
        setCourses(data)
      } catch (error) {
        console.error('Error fetching courses:', error)
        toast.error('Failed to load courses')
      } finally {
        setLoading(false)
      }
    }

    fetchCourses()
  }, [])

  const handleEnroll = async (courseId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) {
        navigate('/login')
        return
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('user_id', user.id)
        .single()

      if (!profile) {
        toast.error('Please complete your profile first')
        return
      }

      const { data: enrollment, error } = await supabase
        .from('enrollments')
        .insert([
          {
            student_id: profile.id,
            course_id: courseId
          }
        ])
        .select()
        .single()

      if (error) throw error

      toast.success('Successfully enrolled!')
      navigate(`/payment?enrollment=${enrollment.id}`)
    } catch (error) {
      console.error('Error enrolling in course:', error)
      toast.error('Failed to enroll in course')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Available Courses</h1>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-white p-6 rounded-lg border border-gray-200 flex flex-col"
          >
            <div className="flex-1">
              <div className="flex items-center justify-between mb-4">
                <BookOpen className="h-8 w-8 text-indigo-600" />
                <div className="flex items-center text-lg font-semibold text-gray-900">
                  <DollarSign className="h-5 w-5" />
                  {course.price.toFixed(2)}
                </div>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {course.title}
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                {course.description}
              </p>
            </div>
            
            <button
              onClick={() => handleEnroll(course.id)}
              className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
            >
              Enroll Now
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}