import React from 'react'
import { Link } from 'react-router-dom'
import { GraduationCap, BookOpen, CreditCard, Users } from 'lucide-react'

export default function Home() {
  return (
    <div className="space-y-12">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 sm:text-6xl">
          Welcome to EduPortal
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Your gateway to quality education. Register for courses, manage your academic journey, and unlock your potential.
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/register"
            className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
          >
            Get Started
          </Link>
          <Link
            to="/courses"
            className="bg-white text-indigo-600 px-6 py-3 rounded-lg font-medium border border-indigo-600 hover:bg-indigo-50 transition-colors"
          >
            View Courses
          </Link>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            icon: GraduationCap,
            title: "Easy Registration",
            description: "Simple and straightforward registration process for new students"
          },
          {
            icon: BookOpen,
            title: "Diverse Courses",
            description: "Wide range of courses across various disciplines"
          },
          {
            icon: CreditCard,
            title: "Secure Payments",
            description: "Safe and secure payment processing for course fees"
          },
          {
            icon: Users,
            title: "Student Dashboard",
            description: "Comprehensive dashboard to manage your academic progress"
          }
        ].map((feature, index) => (
          <div
            key={index}
            className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 text-center"
          >
            <feature.icon className="h-12 w-12 text-indigo-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
            <p className="text-gray-600">{feature.description}</p>
          </div>
        ))}
      </section>

      <section className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Choose EduPortal?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <img
            src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80"
            alt="Students studying"
            className="rounded-lg object-cover h-64 w-full"
          />
          <div className="space-y-4">
            <p className="text-gray-600">
              EduPortal provides a seamless educational experience with:
            </p>
            <ul className="space-y-2">
              {[
                "Modern learning management system",
                "Expert instructors and quality content",
                "Flexible payment options",
                "24/7 student support",
                "Interactive learning resources",
                "Progress tracking and analytics"
              ].map((item, index) => (
                <li key={index} className="flex items-center space-x-2">
                  <div className="h-2 w-2 bg-indigo-600 rounded-full" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  )
}