import React from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { BookOpen, Clock, CheckCircle } from 'lucide-react'

type Enrollment = {
  id: string
  course: {
    title: string
    description: string
    price: number
  }
  status: string
  payment_status: string
  created_at: string
}

export default function Dashboard() {
  const navigate = useNavigate()
  const [enrollments, setEnrollments] = React.useState<Enrollment[]>([])
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    const fetchEnrollments = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        
        if (!user) {
          navigate('/login')
          return
        }

        const { data: profile } = await supabase
          .from('profiles')
          .select('id')
          .eq('user_id', user.id)
          .single()

        if (profile) {
          const { data: enrollmentsData, error } = await supabase
            .from('enrollments')
            .select(`
              id,
              status,
              payment_status,
              created_at,
              course:courses (
                title,
                description,
                price
              )
            `)
            .eq('student_id', profile.id)
            .order('created_at', { ascending: false })

          if (error) throw error
          setEnrollments(enrollmentsData)
        }
      } catch (error) {
        console.error('Error fetching enrollments:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchEnrollments()
  }, [navigate])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">My Dashboard</h1>
        <button
          onClick={() => navigate('/courses')}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <BookOpen className="h-4 w-4 mr-2" />
          Browse Courses
        </button>
      </div>

      {enrollments.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No courses yet</h3>
          <p className="mt-1 text-sm text-gray-500">Get started by enrolling in a course.</p>
          <div className="mt-6">
            <button
              onClick={() => navigate('/courses')}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
            >
              Browse Courses
            </button>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {enrollments.map((enrollment) => (
            <div
              key={enrollment.id}
              className="bg-white p-6 rounded-lg border border-gray-200"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {enrollment.course.title}
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                {enrollment.course.description}
              </p>
              
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <Clock className="h-4 w-4 text-gray-400 mr-2" />
                  <span>Enrolled on {new Date(enrollment.created_at).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 mr-2" 
                    style={{
                      color: enrollment.payment_status === 'completed' 
                        ? '#059669' // green-600
                        : '#DC2626' // red-600
                    }}
                  />
                  <span className="capitalize">{enrollment.payment_status}</span>
                </div>
              </div>

              {enrollment.payment_status === 'pending' && (
                <button
                  onClick={() => navigate(`/payment?enrollment=${enrollment.id}`)}
                  className="mt-4 w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  Complete Payment
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}