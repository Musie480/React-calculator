import React, { useState } from 'react'
import { Calculator, Equal, Delete, Plus, Minus, X, Divide, RotateCcw } from 'lucide-react'

function App() {
  const [display, setDisplay] = useState('0')
  const [equation, setEquation] = useState('')
  const [hasResult, setHasResult] = useState(false)

  const handleNumber = (num: string) => {
    if (hasResult) {
      setDisplay(num)
      setEquation(num)
      setHasResult(false)
    } else {
      setDisplay(display === '0' ? num : display + num)
      setEquation(equation + num)
    }
  }

  const handleOperator = (op: string) => {
    if (!equation.endsWith(' ') && equation !== '') {
      setEquation(equation + ' ' + op + ' ')
      setDisplay('0')
      setHasResult(false)
    }
  }

  const handleEqual = () => {
    try {
      // Replace × with * and ÷ with / for evaluation
      const result = eval(equation.replace(/×/g, '*').replace(/÷/g, '/'))
      setDisplay(result.toString())
      setEquation(result.toString())
      setHasResult(true)
    } catch (error) {
      setDisplay('Error')
      setEquation('')
      setHasResult(true)
    }
  }

  const handleClear = () => {
    setDisplay('0')
    setEquation('')
    setHasResult(false)
  }

  const handleDelete = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1))
      setEquation(equation.slice(0, -1))
    } else {
      setDisplay('0')
    }
  }

  const handleDecimal = () => {
    if (!display.includes('.')) {
      setDisplay(display + '.')
      setEquation(equation + '.')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
          <div className="p-6 bg-indigo-600 text-white">
            <div className="flex items-center justify-between mb-4">
              <Calculator className="h-6 w-6" />
              <h1 className="text-xl font-semibold">Calculator</h1>
            </div>
            <div className="text-right">
              <div className="text-sm opacity-70 h-6 overflow-hidden">
                {equation || '\u00A0'}
              </div>
              <div className="text-4xl font-light tracking-wider overflow-hidden">
                {display}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 p-4 bg-gray-50">
            <button
              onClick={handleClear}
              className="col-span-2 p-4 text-indigo-600 font-semibold bg-indigo-100/50 rounded-2xl hover:bg-indigo-100 transition-colors flex items-center justify-center gap-2"
            >
              <RotateCcw className="h-4 w-4" />
              Clear
            </button>
            <button
              onClick={handleDelete}
              className="p-4 text-indigo-600 font-semibold bg-indigo-100/50 rounded-2xl hover:bg-indigo-100 transition-colors"
            >
              <Delete className="h-5 w-5 mx-auto" />
            </button>
            <button
              onClick={() => handleOperator('÷')}
              className="p-4 text-indigo-600 font-semibold bg-indigo-100/50 rounded-2xl hover:bg-indigo-100 transition-colors"
            >
              <Divide className="h-5 w-5 mx-auto" />
            </button>

            {[7, 8, 9].map((num) => (
              <button
                key={num}
                onClick={() => handleNumber(num.toString())}
                className="p-4 text-gray-700 font-semibold bg-white rounded-2xl hover:bg-gray-50 transition-colors"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleOperator('×')}
              className="p-4 text-indigo-600 font-semibold bg-indigo-100/50 rounded-2xl hover:bg-indigo-100 transition-colors"
            >
              <X className="h-5 w-5 mx-auto" />
            </button>

            {[4, 5, 6].map((num) => (
              <button
                key={num}
                onClick={() => handleNumber(num.toString())}
                className="p-4 text-gray-700 font-semibold bg-white rounded-2xl hover:bg-gray-50 transition-colors"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleOperator('-')}
              className="p-4 text-indigo-600 font-semibold bg-indigo-100/50 rounded-2xl hover:bg-indigo-100 transition-colors"
            >
              <Minus className="h-5 w-5 mx-auto" />
            </button>

            {[1, 2, 3].map((num) => (
              <button
                key={num}
                onClick={() => handleNumber(num.toString())}
                className="p-4 text-gray-700 font-semibold bg-white rounded-2xl hover:bg-gray-50 transition-colors"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleOperator('+')}
              className="p-4 text-indigo-600 font-semibold bg-indigo-100/50 rounded-2xl hover:bg-indigo-100 transition-colors"
            >
              <Plus className="h-5 w-5 mx-auto" />
            </button>

            <button
              onClick={() => handleNumber('0')}
              className="col-span-2 p-4 text-gray-700 font-semibold bg-white rounded-2xl hover:bg-gray-50 transition-colors"
            >
              0
            </button>
            <button
              onClick={handleDecimal}
              className="p-4 text-gray-700 font-semibold bg-white rounded-2xl hover:bg-gray-50 transition-colors"
            >
              .
            </button>
            <button
              onClick={handleEqual}
              className="p-4 text-white font-semibold bg-indigo-600 rounded-2xl hover:bg-indigo-700 transition-colors flex items-center justify-center"
            >
              <Equal className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App